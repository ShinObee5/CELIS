Procedure for Executing and Testing

1.Set directory to file contaning celis_app.py

  C:/CELIS/celis_app/ >  set FLASK_APP=celis_app.py
  C:/CELIS/celis_app/ >  set FLASK_DEBUG=1
  C:/CELIS/celis_app/ >  flask run
  
  
  
  Packages to be installed :
  
  flask_sqlalchemy
  flask_migrate
  flask_login
  flask_wtf
  flask email_validator
  
